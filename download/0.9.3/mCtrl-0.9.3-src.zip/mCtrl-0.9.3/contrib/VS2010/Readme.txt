
This directory contains solution files to build mCtrl with MS Visual Studio.
The solution was created in MS VisualStudio 2010 Express.


Disclaimer
==========

Please note that MS Visual Studio solution and project files are not maintained
continuously as it is not the main development tool of the project so if attempt
to build sources from the repository the project files are likely outdated and
may miss some or some other issues my arise.

However the project files are usually updated before releasing new version so
for the source packages of each release it should build correctly.


Usage
=====

Just open the solution file (mCtrl.sln) where it resides in the project tree
and build it.


Further Notes
=============

* There are usually some warnings when built with VisualStudio, because every
  compiler does not like different things. Hopefully they are not harmfull.
