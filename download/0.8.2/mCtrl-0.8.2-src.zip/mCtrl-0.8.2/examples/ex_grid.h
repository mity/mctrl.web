/*
 * Copyright (c) 2011 Martin Mitas
 *
 * This file contains example code for mCtrl library. Code of this example
 * (but not the library itself) has been placed in the public domain.
 */

#ifndef EXAMPLE_GRID_H
#define EXAMPLE_GRID_H


/* IDs of resources and controls */
#define IDI_BEAR     1000
#define IDC_GRID     100


#endif  /* EXAMPLE_GRID_H */
