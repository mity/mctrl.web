
# mCtrl Authors

The following people (in alphabetical order) have contributed to the mCtrl
project. (Please, let make a merge request or let us know if you are missing
in the list.)

**Jeff Armstrong**  
  WWW: https://github.com/ArmstrongJ
  * Tree-list view multi-selection.
  * Various fixes.

**Martin Mitáš**  
  e-mail: mity@morous.org  
  WWW: https://github.com/mity
  * Founder and main developer.

**Adam Pritchard**  
  WWW: https://github.com/adam-p
  * JavaScript integration to the HTML control.
