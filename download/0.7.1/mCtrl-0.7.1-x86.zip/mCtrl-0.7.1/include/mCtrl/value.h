/*
 * Copyright (c) 2010 Martin Mitas
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef MCTRL_VALUE_H
#define MCTRL_VALUE_H

#include <mCtrl/defs.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file
 * @brief Polymorphic data (@c MC_VALUETYPE and @c MC_VALUE).
 *
 * Some controls are able to cope with large and extensible set of data types.
 * For example grid control (@c ref MC_WC_GRID) is able to present a table
 * of cells where each cell contains another kind of data.
 *
 * @c MC_VALUETYPE and @c MC_VALUE is exactly the abstraction bringing this
 * power to mCtrl. On one side @c MC_VALUE can contain various kinds of data
 * (according to some @c MC_VALUETYPE), on the other side the abstraction
 * allows the grid control to manage the values universally.
 *
 * @c MC_VALUE is an opaque type. It is in effect a handle of the particular
 * piece of data. Therefore the application code cannot manipulate with the
 * data directly, but only indirectly.
 *
 * @c MC_VALUETYPE is also an opaque type which determines how the values of 
 * that type behave. If you are familiar with object oriented programming you
 * can imagine the type is a virtual method table, with the exception that
 * here a pointer to the vtable is not part of the @c MC_VALUE data itself.
 *
 *
 * @section sec_val_basic Basic Usage
 *
 * Most applications will be quite happy with the ability to create (and free)
 * the values and provide them to some control for displaying them and 
 * manipulating them.
 *
 * There is quite a large set of factory functions which create values 
 * of some type. The type is determined implicitly by the factory function
 * used.
 *
 * Then the value is just passed to the control which will display it and
 * potentially alter it. Then in some moment (e.g. when user clicks on OK 
 * button) your application can retrieve the value from the control, call
 * a getter function on it to get the actual data from the value.
 *
 * Please note you have to use a getter method which corresponds to the type
 * of the value. Otherwise the behavior is undefined and your application
 * can even crash.
 *
 * This is also the case when any universal function manipulating with the 
 * value is called. Such function expect @c MC_VALUETYPE as their first 
 * parameter.
 *
 * When you are done with the value you have to release any resources taken by
 * it with @ref mcValueRelease(). This function also expects @c MC_VALUETYPE
 * as its first parameter.
 *
 *
 * @section sec_valtype_define Defining New Value Type
 *
 * Your application can provide new types of values if there is no appropriate
 * built-in type. This in effect extends functionality of controls which 
 * work with the values.
 * 
 * TODO
 * 
 *
 * @section sec_valtype_derive Derived Value Types
 *
 * Furthermore there are functions which create new value types in run time
 * by deriving them from an existing type.
 *
 * For example it is possible to create a new enumeration type of some basic 
 * type (e.g. string). The values of the new type then can only be set to 
 * a value equal to one of the values named during deriving of the type.
 *
 * TODO
 *
 *
 * @section sec_overview Built-in Types
 *
 * <table>
 * <tr><th>Type</th><th>Desrcription</th><th>Factory</th><th>Getter</th></tr>
 * <tr><td>@c int</td><td>32-bit signed integer</td><td>@ref mcValueCreateInt()</td><td>@ref mcValueGetInt()</td></tr>
 * <tr><td>@c UINT</td><td>32-bit unsigned integer</td><td>@ref mcValueCreateUInt()</td><td>@ref mcValueGetUInt()</td></tr>
 * <tr><td>@c INT64</td><td>64-bit signed integer</td><td>@ref mcValueCreateInt64()</td><td>@ref mcValueGetInt64()</td></tr>
 * <tr><td>@c UINT64</td><td>64-bit unsigned integer</td><td>@ref mcValueCreateUInt64()</td><td>@ref mcValueGetUInt64()</td></tr>
 * <tr><td>@c LPCWSTR</td><td>Unicode string</td><td>@ref mcValueCreateStringW()</td><td>@ref mcValueGetStringW()</td></tr>
 * <tr><td>@c LPCSTR</td><td>ANSI string</td><td>@ref mcValueCreateStringA()</td><td>@ref mcValueGetStringA()</td></tr>
 * <tr><td>@c LPCWSTR</td><td>Unicode immutable string</td><td>@ref mcValueCreateImmStringW()</td><td>@ref mcValueGetImmStringW()</td></tr>
 * <tr><td>@c LPCSTR</td><td>ANSI immutable string</td><td>@ref mcValueCreateImmStringA()</td><td>@ref mcValueGetImmStringA()</td></tr>
 * <tr><td>@c COLORREF</td><td>Color RGB triplet</td><td>@ref mcValueCreateColorref()</td><td>@ref mcValueGetColorref()</td></tr>
 * </table>
 */




#ifdef __cplusplus
}  /* extern "C" */
#endif

#endif  /* MCTRL_VALUE_H */
