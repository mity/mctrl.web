
# mCtrl Authors

The following people (in alphabetical order) have contributed to the mCtrl
project. (Please, make a pull request or let us know if you are missing in
the list.)

**Jeff Armstrong** (WWW: https://github.com/ArmstrongJ)
  * Tree-list view multi-selection.
  * Various fixes.

**Martin Mitáš** (WWW: https://github.com/mity, e-mail: mity@morous.org)
  * Founder and main developer.

**Adam Pritchard** (WWW: https://github.com/adam-p)
  * JavaScript integration to the HTML control.
